plugins {
    id("com.android.library")
}

setupCommon()

android {
    namespace = "com.topjohnwu.shared"
}
